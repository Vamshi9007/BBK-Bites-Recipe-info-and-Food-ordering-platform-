let cart = JSON.parse(localStorage.getItem("cart")) || [];

let cartcontent = document.getElementById("cartcontent");
let totalprice = document.getElementById("totalprice");

function displaycart() {
  cartcontent.innerHTML = "";
  let totalBill = 0;

  if (cart.length === 0) {
    cartcontent.innerHTML = "<h2>Please start adding...</h2>";
    totalprice.innerText = "0";
    return;
  }

  cart.map((item, index) => {

    let price = Math.floor(item.rating * 76);
    let itemTotal = price * item.qty;
    totalBill += itemTotal;

    cartcontent.innerHTML += `
      <div>
        <img src="${item.image}" width="120"/>
        <h3>${item.name}</h3>
        <p>Cuisine : ${item.cuisine}</p>
        <p>Price : ${price}/-</p>
        <button onclick="removeItem(${index})">Remove</button>
      </div>
      <hr>
    `;
  });

  totalprice.innerText = totalBill;
}


function removeItem(index) {
  cart.splice(index, 1);
  localStorage.setItem("cart", JSON.stringify(cart));
  displaycart();
}

displaycart();