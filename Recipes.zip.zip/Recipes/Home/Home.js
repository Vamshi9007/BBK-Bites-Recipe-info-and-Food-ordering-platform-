let recipe=[];

function fetchData(){
   fetch("https://dummyjson.com/recipes").then((res)=>{
    return res.json()
}).then((val)=>{
    console.log(val.recipes);
    recipe=val.recipes;
    localStorage.setItem("allrecipes",JSON.stringify(recipe))
    displayCard(recipe)
})
}
function displayCard(v){
    // console.log(prod,"Displayproducts");
    let output="";
    v.map((selectedRecipes)=>{
        let price=Math.floor(selectedRecipes.rating*76);
         output+=`
         <main>
         <img src="${selectedRecipes.image}"/>
        <h1>${selectedRecipes.name}</h1>
        <h3>${"Rating : "+selectedRecipes.rating+"⭐"}</h3>
        <h2>${"Cuisine : "+selectedRecipes.cuisine}</h2>
        <h2>${"Price : "+price+"/-"}</h2>

        <div>
        <button onclick="addToCart(${selectedRecipes.id})">
            Add to cart
          </button>
        <button onclick="seeRecipe(${selectedRecipes.id})">See recipe</button> 

        </div>
        
         
        
         </main>
        `

         
    })
document.getElementById("recipecontainer").innerHTML=output;
}


fetchData()

document.getElementById("searchbar").addEventListener("input", function searchItem(event) {
  let searchTerm = event.target.value.toLowerCase();
  displayCard(
    recipe.filter(v =>
      v.name.toLowerCase().includes(searchTerm) ||
      v.cuisine.toLowerCase().includes(searchTerm)
    )
  );
});


function addToCart(id) {
  let cart = JSON.parse(localStorage.getItem("cart")) || [];
  let allrecipes = JSON.parse(localStorage.getItem("allrecipes"));

  let recipe = allrecipes.filter(item => item.id === id)[0];

  recipe.qty = 1;
  cart.unshift(recipe);

  localStorage.setItem("cart", JSON.stringify(cart));
  window.location.href = "../Cart/cart.html";
}

function seeRecipe(id) {
  localStorage.setItem("recipeId", id);
  window.location.href = "../recipeInfo/recipeinfo.html";
}
