document.getElementById("formContainer").addEventListener("submit",function data(e){

    e.preventDefault()     //it will prevent the default value
    let name=document.getElementById("name").value;
    let email=document.getElementById("email").value;
    let password=document.getElementById("password").value;
    let mobile=document.getElementById("mobile").value;
    errormail=document.getElementById("errormail")
    errorpassword=document.getElementById("errorpassword")

   let emailPattern=/^[^\s@]+@[^\s@]+\.[^\s@]+$/;
   let pwdpattern=/^(?=.*[A-Z])(?=.*[a-z])(?=.*[0-9])(?=.*[!@#$%^&]).{8,}$/;
   if(!emailPattern.test(email))
   {
        errormail.textContent="invalid email..."
        return;
   }
   if(!pwdpattern.test(password))
   {
       errorpassword.textContent="invalid password..."
        return;
   }
    

let Userdata={
    name:name,
    email:email,
    password:password,
    mobile:mobile
}
console.log(Userdata);
localStorage.setItem("userData",JSON.stringify(Userdata));
alert("Registration successfull....")
window.location.href="./login.html"


})