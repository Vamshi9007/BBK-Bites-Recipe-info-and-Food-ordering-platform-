document.getElementById("formContainer").addEventListener("submit", function (e) {
    e.preventDefault();

    let email = document.getElementById("email").value;
    let password = document.getElementById("password").value;

    let logindata = {
        email: email,
        password: password
    };

    
    let storedData = JSON.parse(localStorage.getItem("userData"));
    if(storedData.email==email && storedData.password==password)
    {
        alert("login successful")
        window.location.href="../Home/Home.html"
    }
    else
        alert("invalid credentials")
});
