let recipeinfo=document.getElementById("recipeinfo-container")
let recipeid = localStorage.getItem("recipeId");

let allrecipe=JSON.parse(localStorage.getItem("allrecipes"))

let recipe = allrecipe.filter(item => item.id == recipeid)[0];

recipeinfo.innerHTML = `
  <h1>${recipe.name}</h1>
  <img src="${recipe.image}" width="300"/>
  <p><strong>Cuisine:</strong> ${recipe.cuisine}</p>
  <p><strong>Rating:</strong> ${recipe.rating}</p>
  <p><strong>Calories:</strong> ${recipe.caloriesPerServing}</p>
`;

let ingredientslist = "";
recipe.ingredients.map(item => {
  ingredientslist += `<li>${item}</li>`;
});

recipeinfo.innerHTML += `
  <h2>Ingredients</h2>
  <ul>${ingredientslist}</ul>
`;

let steps = "";
recipe.instructions.map(step => {
  steps += `<li>${step}</li>`;
});

recipeinfo.innerHTML += `
  <h2>Instructions</h2>
  <ol>${steps}</ol>
  <button id="backhome" onclick="window.location.href='../Home/Home.html'">Back to home</button>
`;



